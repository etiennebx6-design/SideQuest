# SideQuest currently keeps WebView JavaScript unobfuscated.
