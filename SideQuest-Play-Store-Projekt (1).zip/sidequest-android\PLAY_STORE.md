# SideQuest für Google Play vorbereiten

1. Öffne diesen Ordner in Android Studio.
2. Beim ersten Öffnen lädt Android Studio die Gradle-Bausteine herunter. Falls eine neuere Android-Plugin-Version vorgeschlagen wird, übernimm sie.
3. Warte auf den Abschluss von „Gradle Sync“ und teste die App mit dem grünen Play-Button auf einem Gerät oder Emulator.
4. Wähle **Build > Generate Signed Bundle / APK > Android App Bundle**.
5. Erstelle ein neues Keystore und bewahre Passwort und Datei sicher auf. Wähle anschließend `release` und erstelle die Datei `.aab`.
6. Öffne die Google Play Console, lege die App mit Paketnamen `de.sidequest.app` an und lade die `.aab` zuerst in den internen Test hoch.

Vor dem öffentlichen Start brauchst du zusätzlich eine Datenschutzerklärung, Store-Screenshots, Kontakt-E-Mail und Inhalte für „Datensicherheit“ in der Play Console. Die App speichert Aufgaben aktuell nur lokal auf dem jeweiligen Gerät und überträgt keine persönlichen Daten.
